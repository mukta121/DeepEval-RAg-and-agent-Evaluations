from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from deepeval.metrics import (
    AnswerRelevancyMetric,
    FaithfulnessMetric,
    ContextualPrecisionMetric,
    ContextualRecallMetric,
    ContextualRelevancyMetric,
    GEval,
    ToolCorrectnessMetric,
    ArgumentCorrectnessMetric,
)

# Safety metrics have changed names/signatures between DeepEval releases.
# Import defensively so a core RAG evaluation never fails only because
# an optional metric is unavailable in the installed version.
try:
    from deepeval.metrics import BiasMetric
except ImportError:
    BiasMetric = None

try:
    from deepeval.metrics import ToxicityMetric
except ImportError:
    ToxicityMetric = None

try:
    from deepeval.metrics import PIILeakageMetric
except ImportError:
    PIILeakageMetric = None

from deepeval.test_case import SingleTurnParams
from .config import Settings


@dataclass(frozen=True)
class MetricSpec:
    name: str
    factory: Callable[[], Any]
    requirements: frozenset[str]
    hard_gate: bool = False


def build_metric_specs(settings: Settings, judge: Any) -> list[MetricSpec]:
    t = settings.thresholds
    verbose = settings.eval_verbose

    specs: list[MetricSpec] = [
        MetricSpec(
            "Answer Relevancy",
            lambda: AnswerRelevancyMetric(
                threshold=t.answer_relevancy,
                model=judge,
                include_reason=True,
                verbose_mode=verbose,
            ),
            frozenset({"actual_output"}),
            hard_gate=True,
        ),
        MetricSpec(
            "Faithfulness",
            lambda: FaithfulnessMetric(
                threshold=t.faithfulness,
                model=judge,
                include_reason=True,
                verbose_mode=verbose,
            ),
            frozenset({"actual_output", "retrieval_context"}),
            hard_gate=True,
        ),
        MetricSpec(
            "Contextual Relevancy",
            lambda: ContextualRelevancyMetric(
                threshold=t.contextual_relevancy,
                model=judge,
                include_reason=True,
                verbose_mode=verbose,
            ),
            frozenset({"actual_output", "retrieval_context"}),
        ),
        MetricSpec(
            "Contextual Precision",
            lambda: ContextualPrecisionMetric(
                threshold=t.contextual_precision,
                model=judge,
                include_reason=True,
                verbose_mode=verbose,
            ),
            frozenset({"actual_output", "expected_output", "retrieval_context"}),
        ),
        MetricSpec(
            "Contextual Recall",
            lambda: ContextualRecallMetric(
                threshold=t.contextual_recall,
                model=judge,
                include_reason=True,
                verbose_mode=verbose,
            ),
            frozenset({"actual_output", "expected_output", "retrieval_context"}),
            hard_gate=True,
        ),

        # Human-golden answer accuracy
        MetricSpec(
            "Correctness",
            lambda: GEval(
                name="Correctness",
                criteria=(
                    "Determine whether the actual output is factually correct "
                    "relative to the expected output. Penalize contradictions, "
                    "incorrect numbers, incorrect conditions, and materially wrong claims."
                ),
                evaluation_params=[
                    SingleTurnParams.INPUT,
                    SingleTurnParams.ACTUAL_OUTPUT,
                    SingleTurnParams.EXPECTED_OUTPUT,
                ],
                threshold=t.correctness,
                model=judge,
            ),
            frozenset({"actual_output", "expected_output"}),
            hard_gate=True,
        ),
        MetricSpec(
            "Completeness",
            lambda: GEval(
                name="Completeness",
                criteria=(
                    "Determine whether the actual output covers all materially important "
                    "facts, conditions, qualifications, exceptions, and sub-questions "
                    "contained in the expected output. Do not reward verbosity by itself."
                ),
                evaluation_params=[
                    SingleTurnParams.INPUT,
                    SingleTurnParams.ACTUAL_OUTPUT,
                    SingleTurnParams.EXPECTED_OUTPUT,
                ],
                threshold=t.completeness,
                model=judge,
            ),
            frozenset({"actual_output", "expected_output"}),
        ),
        MetricSpec(
            "Domain Accuracy",
            lambda: GEval(
                name="Domain Accuracy",
                criteria=(
                    "Evaluate domain accuracy conservatively. Preserve monetary amounts, "
                    "percentages, deductible/copay/coinsurance distinctions, network status, "
                    "coverage conditions, exclusions, limits, and temporal qualifiers. "
                    "The answer must not infer a benefit or rule not supported by the "
                    "expected answer or retrieved context."
                ),
                evaluation_params=[
                    SingleTurnParams.INPUT,
                    SingleTurnParams.ACTUAL_OUTPUT,
                    SingleTurnParams.EXPECTED_OUTPUT,
                    SingleTurnParams.RETRIEVAL_CONTEXT,
                ],
                threshold=t.domain_accuracy,
                model=judge,
            ),
            frozenset({"actual_output", "expected_output", "retrieval_context"}),
            hard_gate=True,
        ),
    ]

    if settings.eval_enable_agent_component_metrics:
        specs.extend(
            [
                MetricSpec(
                    "Tool Correctness",
                    lambda: ToolCorrectnessMetric(
                        threshold=t.tool_correctness,
                        model=judge,
                        include_reason=True,
                    ),
                    frozenset({"actual_output", "tools_called", "expected_tools"}),
                ),
                MetricSpec(
                    "Argument Correctness",
                    lambda: ArgumentCorrectnessMetric(
                        threshold=t.argument_correctness,
                        model=judge,
                        include_reason=True,
                    ),
                    frozenset({"actual_output", "tools_called"}),
                ),
            ]
        )

    if settings.eval_enable_safety:
        if BiasMetric is not None:
            specs.append(
                MetricSpec(
                    "Bias",
                    lambda: BiasMetric(
                        threshold=t.bias,
                        model=judge,
                        include_reason=True,
                    ),
                    frozenset({"actual_output"}),
                )
            )
        if ToxicityMetric is not None:
            specs.append(
                MetricSpec(
                    "Toxicity",
                    lambda: ToxicityMetric(
                        threshold=t.toxicity,
                        model=judge,
                        include_reason=True,
                    ),
                    frozenset({"actual_output"}),
                )
            )
        if PIILeakageMetric is not None:
            specs.append(
                MetricSpec(
                    "PII Leakage",
                    lambda: PIILeakageMetric(
                        threshold=t.pii_leakage,
                        model=judge,
                        include_reason=True,
                    ),
                    frozenset({"actual_output"}),
                )
            )

    return specs
