from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from .app_adapter import ApplicationAdapter, hydrate_case_from_app
from .config import Settings
from .dataset import load_jsonl
from .evaluator import evaluate_case
from .judge import build_judge
from .reporting import aggregate_results, write_excel, write_json


def run() -> int:
    settings = Settings()
    judge = build_judge(settings)
    cases = load_jsonl(settings.eval_input_file)

    adapter = ApplicationAdapter(settings) if settings.app_endpoint else None

    results = []
    for index, case in enumerate(cases, start=1):
        if not case.actual_output:
            if adapter is None:
                raise ValueError(
                    f"{case.case_id}: actual_output is missing and APP_ENDPOINT is not configured."
                )
            case = hydrate_case_from_app(case, adapter)

        print(f"[{index}/{len(cases)}] Evaluating {case.case_id} ...")
        result = evaluate_case(
            case=case,
            question_number=index,
            settings=settings,
            judge=judge,
        )
        results.append(result)

    overall = aggregate_results(results)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    output_dir = settings.eval_output_dir / stamp
    output_dir.mkdir(parents=True, exist_ok=True)

    write_json(output_dir / "question_results.json", results)
    write_json(output_dir / "overall_summary.json", overall)
    write_excel(output_dir / "evaluation_report.xlsx", results, overall)

    print(f"Reports written to: {output_dir}")
    print(f"Hard-gate pass rate: {overall['hard_gate_pass_rate']:.1%}")

    # CI/CD contract: nonzero exit code when any hard-gate case fails.
    return 0 if overall["hard_gate_failed"] == 0 else 2
