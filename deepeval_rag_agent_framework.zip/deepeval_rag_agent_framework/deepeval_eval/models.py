from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, Field


class ToolRecord(BaseModel):
    name: str
    description: str | None = None
    reasoning: str | None = None
    input_parameters: dict[str, Any] | None = None
    output: Any | None = None


class RetrievedChunk(BaseModel):
    chunk_id: str | None = None
    document_id: str | None = None
    content: str
    rank: int | None = None
    score: float | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class EvalCase(BaseModel):
    case_id: str
    query: str
    expected_output: str | None = None

    # Optional ideal source IDs for deterministic retrieval evaluation.
    relevant_chunk_ids: list[str] = Field(default_factory=list)
    relevant_document_ids: list[str] = Field(default_factory=list)

    # Filled either in the golden file or by your app adapter.
    actual_output: str | None = None
    retrieval_context: list[RetrievedChunk] = Field(default_factory=list)

    tools_called: list[ToolRecord] = Field(default_factory=list)
    expected_tools: list[ToolRecord] = Field(default_factory=list)

    # Optional business metadata.
    expected_citations: list[str] = Field(default_factory=list)
    category: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AppResponse(BaseModel):
    actual_output: str
    retrieval_context: list[RetrievedChunk] = Field(default_factory=list)
    tools_called: list[ToolRecord] = Field(default_factory=list)
    latency_seconds: float | None = None
    token_cost: float | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


MetricStatus = Literal["completed", "missing", "not_applicable", "error"]


class MetricResult(BaseModel):
    name: str
    status: MetricStatus
    score: float | None = None
    label: str | None = None
    passed: bool | None = None
    threshold: float | None = None
    reason: str = ""
    details: dict[str, Any] = Field(default_factory=dict)


class QuestionResult(BaseModel):
    case_id: str
    question_number: int
    query: str
    actual_output: str
    expected_output: str | None = None
    metrics: dict[str, MetricResult]
    hard_gate_passed: bool
    applicable_metrics: int
    passed_metrics: int
    failed_metrics: int
    missing_metrics: int
    error_metrics: int
    not_applicable_metrics: int

    @classmethod
    def finalize(
        cls,
        *,
        case: EvalCase,
        question_number: int,
        metrics: dict[str, MetricResult],
        hard_gate_metrics: set[str],
    ) -> "QuestionResult":
        completed = [m for m in metrics.values() if m.status == "completed"]
        passed = [m for m in completed if m.passed is True]
        failed = [m for m in completed if m.passed is False]
        missing = [m for m in metrics.values() if m.status == "missing"]
        errors = [m for m in metrics.values() if m.status == "error"]
        na = [m for m in metrics.values() if m.status == "not_applicable"]

        hard_gate_passed = all(
            (metric := metrics.get(name)) is not None
            and metric.status == "completed"
            and metric.passed is True
            for name in hard_gate_metrics
        )

        return cls(
            case_id=case.case_id,
            question_number=question_number,
            query=case.query,
            actual_output=case.actual_output or "",
            expected_output=case.expected_output,
            metrics=metrics,
            hard_gate_passed=hard_gate_passed,
            applicable_metrics=len(completed),
            passed_metrics=len(passed),
            failed_metrics=len(failed),
            missing_metrics=len(missing),
            error_metrics=len(errors),
            not_applicable_metrics=len(na),
        )
