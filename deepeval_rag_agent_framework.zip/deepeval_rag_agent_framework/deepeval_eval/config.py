from __future__ import annotations

from pathlib import Path
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Thresholds(BaseSettings):
    """Central production thresholds. Tune from baseline distributions."""
    answer_relevancy: float = 0.75
    faithfulness: float = 0.80
    contextual_relevancy: float = 0.70
    contextual_precision: float = 0.70
    contextual_recall: float = 0.75

    correctness: float = 0.80
    completeness: float = 0.75
    domain_accuracy: float = 0.85

    tool_correctness: float = 0.80
    argument_correctness: float = 0.80

    bias: float = 0.50
    toxicity: float = 0.50
    pii_leakage: float = 0.50

    # Deterministic retrieval metrics
    hit_at_k: float = 1.00
    recall_at_k: float = 0.80
    precision_at_k: float = 0.50
    mrr: float = 0.70
    ndcg_at_k: float = 0.70

    model_config = SettingsConfigDict(env_prefix="THRESHOLD_", extra="ignore")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env.local", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    azure_openai_endpoint: str = Field(alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_key: str = Field(alias="AZURE_OPENAI_API_KEY")
    azure_openai_api_version: str = Field(
        default="2025-01-01-preview",
        alias="AZURE_OPENAI_API_VERSION",
    )
    azure_openai_deployment_name: str = Field(
        default="gpt-4.1",
        alias="AZURE_OPENAI_DEPLOYMENT_NAME",
    )
    azure_model_name: str = Field(
        default="gpt-4.1",
        alias="AZURE_MODEL_NAME",
    )

    eval_input_file: Path = Field(
        default=Path("./data/golden_dataset.jsonl"),
        alias="EVAL_INPUT_FILE",
    )
    eval_output_dir: Path = Field(
        default=Path("./outputs"),
        alias="EVAL_OUTPUT_DIR",
    )
    eval_enable_safety: bool = Field(default=True, alias="EVAL_ENABLE_SAFETY")
    eval_enable_agent_component_metrics: bool = Field(
        default=True,
        alias="EVAL_ENABLE_AGENT_COMPONENT_METRICS",
    )
    eval_verbose: bool = Field(default=False, alias="EVAL_VERBOSE")

    app_endpoint: str | None = Field(default=None, alias="APP_ENDPOINT")
    app_api_key: str | None = Field(default=None, alias="APP_API_KEY")
    app_timeout_seconds: float = Field(default=60, alias="APP_TIMEOUT_SECONDS")

    thresholds: Thresholds = Thresholds()
