from __future__ import annotations

import time
import httpx

from .config import Settings
from .models import AppResponse, EvalCase, RetrievedChunk, ToolRecord


class ApplicationAdapter:
    """
    Replace this class if your RAG API has a different request/response contract.

    Expected example response:
    {
      "answer": "...",
      "retrieved_chunks": [
        {"chunk_id": "...", "document_id": "...", "content": "...", "score": 0.91}
      ],
      "tools_called": [
        {"name": "search_policy", "input_parameters": {"query": "..."}}
      ],
      "token_cost": 0.0012
    }
    """

    def __init__(self, settings: Settings):
        if not settings.app_endpoint:
            raise ValueError("APP_ENDPOINT is not configured.")
        self.endpoint = settings.app_endpoint
        self.api_key = settings.app_api_key
        self.timeout = settings.app_timeout_seconds

    def invoke(self, case: EvalCase) -> AppResponse:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        started = time.perf_counter()
        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                self.endpoint,
                headers=headers,
                json={"query": case.query, "case_id": case.case_id},
            )
            response.raise_for_status()
            data = response.json()
        latency = time.perf_counter() - started

        return AppResponse(
            actual_output=data["answer"],
            retrieval_context=[
                RetrievedChunk.model_validate(x)
                for x in data.get("retrieved_chunks", [])
            ],
            tools_called=[
                ToolRecord.model_validate(x)
                for x in data.get("tools_called", [])
            ],
            latency_seconds=latency,
            token_cost=data.get("token_cost"),
            raw=data,
        )


def hydrate_case_from_app(case: EvalCase, adapter: ApplicationAdapter) -> EvalCase:
    response = adapter.invoke(case)
    updated = case.model_copy(deep=True)
    updated.actual_output = response.actual_output
    updated.retrieval_context = response.retrieval_context
    updated.tools_called = response.tools_called
    updated.metadata["latency_seconds"] = response.latency_seconds
    updated.metadata["token_cost"] = response.token_cost
    return updated
