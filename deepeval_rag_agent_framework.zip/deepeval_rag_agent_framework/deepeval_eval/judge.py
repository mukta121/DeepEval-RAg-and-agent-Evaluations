from __future__ import annotations

from deepeval.models import AzureOpenAIModel
from .config import Settings


def build_judge(settings: Settings) -> AzureOpenAIModel:
    """Use Azure OpenAI directly as the DeepEval judge."""
    return AzureOpenAIModel(
        model=settings.azure_model_name,
        deployment_name=settings.azure_openai_deployment_name,
        api_key=settings.azure_openai_api_key,
        api_version=settings.azure_openai_api_version,
        base_url=settings.azure_openai_endpoint,
        temperature=0,
    )
