from __future__ import annotations

from typing import Any
from deepeval.test_case import LLMTestCase, ToolCall

from .config import Settings
from .deterministic_metrics import retrieval_metrics
from .metric_registry import MetricSpec, build_metric_specs
from .models import EvalCase, MetricResult, QuestionResult, ToolRecord


def _to_tool_call(record: ToolRecord) -> ToolCall:
    return ToolCall(
        name=record.name,
        description=record.description,
        reasoning=record.reasoning,
        input_parameters=record.input_parameters,
        output=record.output,
    )


def _has(case: EvalCase, field: str) -> bool:
    value = getattr(case, field)
    if value is None:
        return False
    if isinstance(value, (str, list, dict)):
        return bool(value)
    return True


def build_test_case(case: EvalCase) -> LLMTestCase:
    return LLMTestCase(
        input=case.query,
        actual_output=case.actual_output or "",
        expected_output=case.expected_output,
        retrieval_context=[c.content for c in case.retrieval_context] or None,
        tools_called=[_to_tool_call(t) for t in case.tools_called] or None,
        expected_tools=[_to_tool_call(t) for t in case.expected_tools] or None,
    )


def _metric_threshold(metric: Any) -> float | None:
    value = getattr(metric, "threshold", None)
    return float(value) if isinstance(value, (int, float)) else None


def _metric_success(metric: Any, score: float | None, threshold: float | None) -> bool | None:
    # Prefer DeepEval's own success calculation because some safety metrics
    # may have directionality/strictness different from "higher is better".
    is_successful = getattr(metric, "is_successful", None)
    if callable(is_successful):
        try:
            return bool(is_successful())
        except Exception:
            pass
    success = getattr(metric, "success", None)
    if isinstance(success, bool):
        return success
    if score is not None and threshold is not None:
        return score >= threshold
    return None


def run_native_metric(
    spec: MetricSpec,
    case: EvalCase,
    test_case: LLMTestCase,
) -> MetricResult:
    missing_fields = sorted(field for field in spec.requirements if not _has(case, field))
    if missing_fields:
        # expected_output absent => reference metric truly N/A.
        if "expected_output" in missing_fields:
            return MetricResult(
                name=spec.name,
                status="not_applicable",
                reason=f"Requires: {', '.join(missing_fields)}.",
            )
        return MetricResult(
            name=spec.name,
            status="missing",
            reason=f"Missing required data: {', '.join(missing_fields)}.",
        )

    metric = spec.factory()
    threshold = _metric_threshold(metric)

    try:
        metric.measure(test_case)
        score_raw = getattr(metric, "score", None)
        score = float(score_raw) if isinstance(score_raw, (int, float)) else None
        reason = str(getattr(metric, "reason", "") or "")
        passed = _metric_success(metric, score, threshold)

        return MetricResult(
            name=spec.name,
            status="completed",
            score=score,
            threshold=threshold,
            passed=passed,
            reason=reason,
            details={
                "metric_class": type(metric).__name__,
                "evaluation_model": str(getattr(metric, "evaluation_model", "") or ""),
            },
        )
    except Exception as exc:
        return MetricResult(
            name=spec.name,
            status="error",
            threshold=threshold,
            passed=False if spec.hard_gate else None,
            reason=f"{type(exc).__name__}: {exc}",
            details={"metric_class": type(metric).__name__},
        )


def evaluate_case(
    case: EvalCase,
    question_number: int,
    settings: Settings,
    judge: Any,
) -> QuestionResult:
    if not case.actual_output:
        raise ValueError(
            f"Case {case.case_id} has no actual_output. "
            "Run the application adapter first or provide actual_output in JSONL."
        )

    test_case = build_test_case(case)
    specs = build_metric_specs(settings, judge)
    metrics: dict[str, MetricResult] = {}

    for spec in specs:
        metrics[spec.name] = run_native_metric(spec, case, test_case)

    metrics.update(retrieval_metrics(case, settings.thresholds))

    hard_gate_metrics = {s.name for s in specs if s.hard_gate}
    # Deterministic retrieval quality gate when a chunk-level golden exists.
    if case.relevant_chunk_ids:
        hard_gate_metrics.update({"Hit@K", "Recall@K"})

    return QuestionResult.finalize(
        case=case,
        question_number=question_number,
        metrics=metrics,
        hard_gate_metrics=hard_gate_metrics,
    )
