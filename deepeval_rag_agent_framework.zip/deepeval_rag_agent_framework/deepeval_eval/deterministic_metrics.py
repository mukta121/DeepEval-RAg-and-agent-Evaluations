from __future__ import annotations

import math
from .models import EvalCase, MetricResult


def _retrieved_ids(case: EvalCase) -> list[str]:
    return [
        chunk.chunk_id
        for chunk in case.retrieval_context
        if chunk.chunk_id is not None
    ]


def _relevant_ids(case: EvalCase) -> set[str]:
    return set(case.relevant_chunk_ids)


def retrieval_metrics(case: EvalCase, thresholds) -> dict[str, MetricResult]:
    """
    Compute reference-based deterministic IR metrics.
    These complement, rather than duplicate, DeepEval's LLM-judge RAG metrics.
    """
    results: dict[str, MetricResult] = {}
    retrieved = _retrieved_ids(case)
    relevant = _relevant_ids(case)

    names = ["Hit@K", "Recall@K", "Precision@K", "MRR", "NDCG@K"]

    if not case.retrieval_context:
        for name in names:
            results[name] = MetricResult(
                name=name,
                status="missing",
                reason="No retrieval_context was provided.",
            )
        return results

    if not relevant:
        for name in names:
            results[name] = MetricResult(
                name=name,
                status="not_applicable",
                reason="No relevant_chunk_ids are defined in the golden dataset.",
            )
        return results

    hits = [1 if rid in relevant else 0 for rid in retrieved]
    hit_at_k = float(any(hits))
    recall = sum(hits) / len(relevant) if relevant else 0.0
    precision = sum(hits) / len(retrieved) if retrieved else 0.0

    rr = 0.0
    for rank, is_hit in enumerate(hits, start=1):
        if is_hit:
            rr = 1.0 / rank
            break

    dcg = sum(hit / math.log2(rank + 1) for rank, hit in enumerate(hits, start=1))
    ideal_hits = [1] * min(len(relevant), len(retrieved))
    idcg = sum(hit / math.log2(rank + 1) for rank, hit in enumerate(ideal_hits, start=1))
    ndcg = dcg / idcg if idcg else 0.0

    values = {
        "Hit@K": (hit_at_k, thresholds.hit_at_k),
        "Recall@K": (recall, thresholds.recall_at_k),
        "Precision@K": (precision, thresholds.precision_at_k),
        "MRR": (rr, thresholds.mrr),
        "NDCG@K": (ndcg, thresholds.ndcg_at_k),
    }

    for name, (score, threshold) in values.items():
        results[name] = MetricResult(
            name=name,
            status="completed",
            score=score,
            threshold=threshold,
            passed=score >= threshold,
            reason="Deterministic information-retrieval metric.",
            details={
                "retrieved_chunk_ids": retrieved,
                "relevant_chunk_ids": sorted(relevant),
                "k": len(retrieved),
            },
        )

    return results
