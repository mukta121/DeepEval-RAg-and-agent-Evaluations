from deepeval_eval.runner import run

if __name__ == "__main__":
    raise SystemExit(run())
