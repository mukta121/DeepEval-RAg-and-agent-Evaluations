"""Optional pytest CI gate using the same framework."""
from pathlib import Path
import pytest

from deepeval_eval.config import Settings
from deepeval_eval.dataset import load_jsonl
from deepeval_eval.evaluator import evaluate_case
from deepeval_eval.judge import build_judge


settings = Settings()
judge = build_judge(settings)
cases = load_jsonl(settings.eval_input_file)


@pytest.mark.parametrize("index,case", list(enumerate(cases, start=1)))
def test_rag_quality(index, case):
    if not case.actual_output:
        pytest.skip("This test expects actual_output in the dataset.")
    result = evaluate_case(case, index, settings, judge)
    assert result.hard_gate_passed, (
        f"{case.case_id} failed hard gate. "
        f"Failed metrics: "
        f"{[name for name, m in result.metrics.items() if m.passed is False]}"
    )
