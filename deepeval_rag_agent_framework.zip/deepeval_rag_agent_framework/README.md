# DeepEval Production RAG + Agent Evaluation Framework

This project is a production-oriented replacement/companion for a Foundry SDK
evaluation runner. It keeps explicit hard gates, missing/N/A/error handling,
JSON audit output, Excel reporting, and CI-friendly exit codes.

## Metric coverage

### Native DeepEval RAG
- Answer Relevancy
- Faithfulness
- Contextual Relevancy
- Contextual Precision
- Contextual Recall

### Custom DeepEval GEval
- Correctness against a human golden answer
- Completeness
- Domain Accuracy

### Agent component metrics
- Tool Correctness
- Argument Correctness

### Full agent trajectory metrics
In `agent_trace_example.py`:
- Plan Quality
- Plan Adherence
- Task Completion
- Step Efficiency

These require real DeepEval tracing; they should not be fabricated from a flat
offline record.

### Deterministic retrieval metrics
- Hit@K
- Recall@K
- Precision@K
- MRR
- NDCG@K

### Optional safety metrics
Loaded defensively when supported by the installed DeepEval version:
- Bias
- Toxicity
- PII Leakage

## Project layout

```text
deepeval_rag_agent_framework/
├── .env.example
├── requirements.txt
├── run_eval.py
├── agent_trace_example.py
├── test_quality_gate.py
├── data/
│   └── golden_dataset.jsonl
└── deepeval_eval/
    ├── app_adapter.py
    ├── config.py
    ├── dataset.py
    ├── deterministic_metrics.py
    ├── evaluator.py
    ├── judge.py
    ├── metric_registry.py
    ├── models.py
    ├── reporting.py
    └── runner.py
```

## 1. Install

```bash
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install -r requirements.txt
```

## 2. Configure Azure OpenAI judge

Copy `.env.example` to `.env` and populate:

```env
AZURE_OPENAI_ENDPOINT=https://YOUR-RESOURCE.openai.azure.com/
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_API_VERSION=2025-01-01-preview
AZURE_OPENAI_DEPLOYMENT_NAME=gpt-4.1
AZURE_MODEL_NAME=gpt-4.1
```

Do not commit `.env`.

## 3. Golden dataset

The minimum useful RAG record is:

```json
{
  "case_id": "case_001",
  "query": "question",
  "expected_output": "human-approved answer",
  "actual_output": "answer returned by the app",
  "retrieval_context": [
    {
      "chunk_id": "chunk_123",
      "document_id": "doc_1",
      "content": "retrieved text"
    }
  ],
  "relevant_chunk_ids": ["chunk_123"]
}
```

`expected_output` enables reference metrics such as Contextual Precision,
Contextual Recall, Correctness and Completeness.

`relevant_chunk_ids` enables deterministic Hit@K, Recall@K, Precision@K, MRR
and NDCG@K.

## 4. Run with outputs already captured

```bash
python run_eval.py
```

Outputs:

```text
outputs/<timestamp>/
├── question_results.json
├── overall_summary.json
└── evaluation_report.xlsx
```

## 5. Run directly against your RAG API

Leave `actual_output` empty in the golden dataset and configure:

```env
APP_ENDPOINT=https://your-api/evaluate
APP_API_KEY=...
```

Then adapt `deepeval_eval/app_adapter.py` to the exact response contract of
your application.

The default adapter expects:

```json
{
  "answer": "...",
  "retrieved_chunks": [
    {
      "chunk_id": "...",
      "document_id": "...",
      "content": "...",
      "score": 0.91
    }
  ],
  "tools_called": [
    {
      "name": "search_policy",
      "input_parameters": {"query": "..."}
    }
  ]
}
```

## 6. Hard gates

Default hard gates:
- Answer Relevancy
- Faithfulness
- Contextual Recall
- Correctness
- Domain Accuracy
- Hit@K and Recall@K when `relevant_chunk_ids` exist

A metric that errors or is missing never silently passes a hard gate.

Tune thresholds only after establishing baseline distributions on a
representative human-reviewed dataset.

## 7. Agent evaluation

Tool Correctness and Argument Correctness can be evaluated from captured
`tools_called`.

Plan Quality, Plan Adherence, Task Completion and Step Efficiency need the
agent's actual trace. Use `agent_trace_example.py` as the integration pattern.
Instrument the top-level agent and nested retrievers/tools/sub-agents.

## 8. CI/CD

The runner exits:
- `0`: all hard-gate cases passed
- `2`: at least one case failed a hard gate

Example:

```bash
python run_eval.py
```

or:

```bash
pytest -q test_quality_gate.py
```

## Recommended production policy

Do not collapse every metric into one averaged "quality score".
A high average can hide a critical hallucination or retrieval miss.

Use:
1. hard gates for critical quality dimensions,
2. per-metric distributions for diagnosis,
3. deterministic IR metrics for retrieval regression,
4. DeepEval judge metrics for semantic quality,
5. trace metrics for agent behavior,
6. latency/cost separately as operational KPIs.
