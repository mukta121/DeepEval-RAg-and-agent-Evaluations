"""
Full agent trajectory evaluation.

Why separate from the normal runner?
DeepEval's PlanQualityMetric, PlanAdherenceMetric, TaskCompletionMetric and
StepEfficiencyMetric require a captured execution trace. A flat JSONL row
cannot reconstruct the agent's real trajectory reliably.

Replace `your_agent()` with your production agent and instrument nested
retrievers/tools/subagents with @observe() or the integration callback for
your agent framework.
"""

from deepeval.dataset import EvaluationDataset, Golden
from deepeval.evaluate import AsyncConfig
from deepeval.metrics import (
    PlanQualityMetric,
    PlanAdherenceMetric,
    TaskCompletionMetric,
    StepEfficiencyMetric,
)
from deepeval.tracing import observe, update_current_trace

from deepeval_eval.config import Settings
from deepeval_eval.judge import build_judge


settings = Settings()
judge = build_judge(settings)


@observe()
def your_agent(query: str) -> str:
    # ------------------------------------------------------------
    # Replace this stub with your real agent.
    # Instrument nested operations too:
    #
    # @observe(type="retriever")
    # def retrieve(...): ...
    #
    # @observe(type="tool")
    # def search_policy(...): ...
    #
    # @observe(type="agent")
    # def sub_agent(...): ...
    # ------------------------------------------------------------
    answer = f"STUB: production agent should answer: {query}"

    # Sets trace-level fields used by trajectory metrics.
    update_current_trace(input=query, output=answer)
    return answer


dataset = EvaluationDataset(
    goldens=[
        Golden(input="What is the out-of-network deductible?"),
        Golden(input="Find the deductible and explain whether ER care counts toward it."),
    ]
)

trajectory_metrics = [
    PlanQualityMetric(threshold=0.70, model=judge),
    PlanAdherenceMetric(threshold=0.70, model=judge),
    TaskCompletionMetric(threshold=0.80, model=judge),
    StepEfficiencyMetric(threshold=0.70, model=judge),
]

for golden in dataset.evals_iterator(
    metrics=trajectory_metrics,
    async_config=AsyncConfig(run_async=False),
):
    your_agent(golden.input)
