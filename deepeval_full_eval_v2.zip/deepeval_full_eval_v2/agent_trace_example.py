from deepeval.metrics import PlanQualityMetric, PlanAdherenceMetric, TaskCompletionMetric, StepEfficiencyMetric
from deepeval.tracing import observe, update_current_trace
from deepeval_eval.config import Settings
from deepeval_eval.judge import build_judge

settings = Settings()
judge = build_judge(settings)

trajectory_metrics = [
    PlanQualityMetric(threshold=0.70, model=judge),
    PlanAdherenceMetric(threshold=0.70, model=judge),
    TaskCompletionMetric(threshold=0.80, model=judge),
    StepEfficiencyMetric(threshold=0.70, model=judge),
]

@observe()
def production_agent(query: str) -> str:
    answer = f"STUB answer for: {query}"
    update_current_trace(input=query, output=answer)
    return answer
