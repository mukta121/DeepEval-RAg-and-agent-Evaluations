from __future__ import annotations
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

class Thresholds(BaseSettings):
    answer_relevancy: float = 0.75
    faithfulness: float = 0.80
    contextual_relevancy: float = 0.70
    contextual_precision: float = 0.70
    contextual_recall: float = 0.75
    correctness: float = 0.80
    completeness: float = 0.75
    domain_accuracy: float = 0.85
    tool_correctness: float = 0.80
    argument_correctness: float = 0.80
    hit_at_k: float = 1.00
    recall_at_k: float = 0.80
    precision_at_k: float = 0.50
    mrr: float = 0.70
    ndcg_at_k: float = 0.70
    model_config = SettingsConfigDict(env_prefix="THRESHOLD_", extra="ignore")

class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=(".env.local", ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
    )
    azure_openai_endpoint: str = Field(alias="AZURE_OPENAI_ENDPOINT")
    azure_openai_api_key: str = Field(alias="AZURE_OPENAI_API_KEY")
    azure_openai_api_version: str = Field(default="2025-01-01-preview", alias="AZURE_OPENAI_API_VERSION")
    azure_openai_deployment_name: str = Field(default="gpt-4.1", alias="AZURE_OPENAI_DEPLOYMENT_NAME")
    azure_model_name: str = Field(default="gpt-4.1", alias="AZURE_MODEL_NAME")
    eval_verbose: bool = Field(default=False, alias="EVAL_VERBOSE")
    enable_safety: bool = Field(default=True, alias="ENABLE_SAFETY")
    enable_agent_metrics: bool = Field(default=True, alias="ENABLE_AGENT_METRICS")
    thresholds: Thresholds = Thresholds()
