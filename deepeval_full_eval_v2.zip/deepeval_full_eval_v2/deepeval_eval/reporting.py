import json
from collections import defaultdict
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

def aggregate_results(results):
    if not results:
        return {"question_count": 0, "hard_gate_passed": 0, "hard_gate_failed": 0, "hard_gate_pass_rate": 0.0, "metrics": {}}

    buckets = defaultdict(list)
    for q in results:
        for name, metric in q.metrics.items():
            buckets[name].append(metric)

    summary = {}
    for name, values in sorted(buckets.items()):
        completed = [v for v in values if v.status == "completed"]
        scores = [v.score for v in completed if v.score is not None]
        passed = sum(v.passed is True for v in completed)
        failed = sum(v.passed is False for v in completed)
        summary[name] = {
            "completed": len(completed),
            "passed": passed,
            "failed": failed,
            "pass_rate": passed / len(completed) if completed else None,
            "mean_score": sum(scores) / len(scores) if scores else None,
            "missing": sum(v.status == "missing" for v in values),
            "errors": sum(v.status == "error" for v in values),
            "not_applicable": sum(v.status == "not_applicable" for v in values),
        }

    hard_passed = sum(q.hard_gate_passed for q in results)
    return {
        "question_count": len(results),
        "hard_gate_passed": hard_passed,
        "hard_gate_failed": len(results) - hard_passed,
        "hard_gate_pass_rate": hard_passed / len(results),
        "metrics": summary,
    }

def write_json(path, payload):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False, default=str), encoding="utf-8")

def _autosize(ws, max_width=70):
    for cells in ws.columns:
        letter = get_column_letter(cells[0].column)
        width = min(max(len(str(c.value)) if c.value is not None else 0 for c in cells) + 2, max_width)
        ws.column_dimensions[letter].width = max(width, 10)

def write_excel(path, results, overall):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)

    ws = wb.active
    ws.title = "Question Results"
    metric_names = sorted({name for r in results for name in r.metrics})
    headers = ["Question #", "Case ID", "Question", "Actual Output", "Expected Output", *metric_names, "Passed / Applicable", "Missing", "Errors", "N/A", "Hard Gate"]
    ws.append(headers)
    for c in ws[1]:
        c.fill = header_fill
        c.font = header_font

    for r in results:
        row = [r.question_number, r.case_id, r.query, r.actual_output, r.expected_output or ""]
        for name in metric_names:
            m = r.metrics[name]
            if m.status == "not_applicable":
                row.append("N/A")
            elif m.status == "missing":
                row.append("MISSING")
            elif m.status == "error":
                row.append("ERROR")
            else:
                row.append(m.score if m.score is not None else "COMPLETED")
        row += [f"{r.passed_metrics}/{r.applicable_metrics}", r.missing_metrics, r.error_metrics, r.not_applicable_metrics, "PASS" if r.hard_gate_passed else "FAIL"]
        ws.append(row)
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    _autosize(ws)

    sws = wb.create_sheet("Metric Summary")
    sws.append(["Metric", "Completed", "Passed", "Failed", "Pass Rate", "Mean Score", "Missing", "Errors", "Not Applicable"])
    for c in sws[1]:
        c.fill = header_fill
        c.font = header_font
    for name, m in overall["metrics"].items():
        sws.append([name, m["completed"], m["passed"], m["failed"], m["pass_rate"], m["mean_score"], m["missing"], m["errors"], m["not_applicable"]])
    sws.append([])
    sws.append(["Overall Hard Gate Pass Rate", overall["hard_gate_pass_rate"]])
    _autosize(sws)

    dws = wb.create_sheet("Metric Details")
    dws.append(["Question #", "Case ID", "Metric", "Status", "Score", "Threshold", "Passed", "Reason", "Details"])
    for c in dws[1]:
        c.fill = header_fill
        c.font = header_font
    for r in results:
        for name, m in sorted(r.metrics.items()):
            dws.append([r.question_number, r.case_id, name, m.status, m.score, m.threshold, m.passed, m.reason, json.dumps(m.details, ensure_ascii=False, default=str)])
    for row in dws.iter_rows(min_row=2):
        row[7].alignment = Alignment(wrap_text=True, vertical="top")
        row[8].alignment = Alignment(wrap_text=True, vertical="top")
    dws.freeze_panes = "A2"
    _autosize(dws)

    wb.save(path)
