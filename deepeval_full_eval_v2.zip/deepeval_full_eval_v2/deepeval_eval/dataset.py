from __future__ import annotations
import json
from pathlib import Path
from typing import Any
from .models import GroundTruthCase, ResponseCase, EvalCase

ALIASES = {
    "case_id": ("case_id", "id", "question_id", "test_case_id"),
    "query": ("query", "question", "input", "prompt"),
    "expected_output": ("expected_output", "expected_answer", "ground_truth", "ground_truth_answer", "answer", "reference_answer"),
    "actual_output": ("actual_output", "response", "generated_answer", "model_answer", "rag_answer", "output"),
    "retrieval_context": ("retrieval_context", "retrieved_chunks", "contexts", "context", "retrieved_context"),
    "relevant_chunk_ids": ("relevant_chunk_ids", "expected_chunk_ids", "gold_chunk_ids"),
    "relevant_document_ids": ("relevant_document_ids", "expected_document_ids", "gold_document_ids"),
}

def _read_json_or_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    if path.suffix.lower() == ".jsonl":
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for line_no, line in enumerate(f, start=1):
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                if not isinstance(obj, dict):
                    raise ValueError(f"{path}: line {line_no} must be an object")
                rows.append(obj)
        return rows

    if path.suffix.lower() != ".json":
        raise ValueError(f"{path}: only .json and .jsonl are supported")

    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in ("data", "cases", "golden_data", "goldens", "test_cases", "evaluation_cases", "responses", "results"):
            if isinstance(payload.get(key), list):
                return payload[key]
        return [payload]
    raise ValueError(f"{path}: expected JSON array or object")

def _first(record, names):
    for name in names:
        if name in record and record[name] is not None:
            return record[name]
    return None

def _normalize_chunk(item, index):
    if isinstance(item, str):
        return {"content": item, "rank": index}
    if not isinstance(item, dict):
        return {"content": str(item), "rank": index}

    out = dict(item)
    if "content" not in out:
        for key in ("text", "chunk_text", "page_content", "document", "passage"):
            if key in out:
                out["content"] = out[key]
                break
    out.setdefault("content", "")
    out.setdefault("rank", index)

    if "chunk_id" not in out:
        for key in ("id", "chunkId", "chunk_key"):
            if key in out:
                out["chunk_id"] = out[key]
                break

    if "document_id" not in out:
        for key in ("documentId", "doc_id", "source_document_id"):
            if key in out:
                out["document_id"] = out[key]
                break
    return out

def _normalize_record(record, *, kind, index):
    out = dict(record)

    for canonical, aliases in ALIASES.items():
        if canonical not in out:
            value = _first(record, aliases)
            if value is not None:
                out[canonical] = value

    if not out.get("case_id"):
        out["case_id"] = f"Q{index:05d}"

    if kind == "ground_truth" and not out.get("query"):
        raise ValueError(f"Ground truth record #{index} has no query/question")
    if kind == "response" and not out.get("actual_output"):
        raise ValueError(f"Response record #{index} has no response/output")

    context = out.get("retrieval_context")
    if context is not None:
        if not isinstance(context, list):
            context = [context]
        out["retrieval_context"] = [
            _normalize_chunk(item, idx)
            for idx, item in enumerate(context, start=1)
        ]
    return out

def load_ground_truth(path: Path | str) -> list[GroundTruthCase]:
    rows = _read_json_or_jsonl(Path(path))
    return [
        GroundTruthCase.model_validate(_normalize_record(r, kind="ground_truth", index=i))
        for i, r in enumerate(rows, start=1)
    ]

def load_responses(path: Path | str) -> list[ResponseCase]:
    rows = _read_json_or_jsonl(Path(path))
    return [
        ResponseCase.model_validate(_normalize_record(r, kind="response", index=i))
        for i, r in enumerate(rows, start=1)
    ]

def merge_ground_truth_and_responses(ground_truth, responses) -> list[EvalCase]:
    if len({x.case_id for x in ground_truth}) != len(ground_truth):
        raise ValueError("Duplicate case_id in ground truth")
    if len({x.case_id for x in responses}) != len(responses):
        raise ValueError("Duplicate case_id in responses")

    response_by_id = {r.case_id: r for r in responses}

    def nq(text):
        return " ".join((text or "").casefold().split())

    response_by_query = {}
    for r in responses:
        q = nq(r.query)
        if q and q not in response_by_query:
            response_by_query[q] = r

    merged = []
    used = set()

    for gt in ground_truth:
        response = response_by_id.get(gt.case_id) or response_by_query.get(nq(gt.query))
        if response is None:
            raise ValueError(f"No response matched {gt.case_id}: {gt.query}")

        used.add(response.case_id)
        metadata = dict(gt.metadata)
        metadata.update({
            "response_metadata": response.metadata,
            "latency_seconds": response.latency_seconds,
            "token_cost": response.token_cost,
            "query_mismatch": bool(response.query and nq(response.query) != nq(gt.query)),
        })

        merged.append(EvalCase(
            case_id=gt.case_id,
            query=gt.query,
            expected_output=gt.expected_output,
            actual_output=response.actual_output,
            relevant_chunk_ids=gt.relevant_chunk_ids,
            relevant_document_ids=gt.relevant_document_ids,
            retrieval_context=response.retrieval_context,
            tools_called=response.tools_called,
            expected_tools=gt.expected_tools,
            citations=response.citations,
            expected_citations=gt.expected_citations,
            category=gt.category,
            metadata=metadata,
        ))

    unused = sorted(set(r.case_id for r in responses) - used)
    if unused:
        print(f"WARNING: unused response case_ids: {unused[:10]}")
    return merged
