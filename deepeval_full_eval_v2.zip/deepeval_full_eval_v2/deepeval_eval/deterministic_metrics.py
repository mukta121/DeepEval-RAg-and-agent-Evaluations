import math
from .models import MetricResult

def evaluate_retrieval(case, thresholds):
    names = ["Hit@K", "Recall@K", "Precision@K", "MRR", "NDCG@K"]

    if not case.retrieval_context:
        return {n: MetricResult(name=n, status="missing", reason="No retrieval_context") for n in names}

    relevant = set(case.relevant_chunk_ids)
    if not relevant:
        return {n: MetricResult(name=n, status="not_applicable", reason="No relevant_chunk_ids in ground truth") for n in names}

    retrieved = [c.chunk_id for c in case.retrieval_context if c.chunk_id]
    if not retrieved:
        return {n: MetricResult(name=n, status="missing", reason="Retrieved chunks have no chunk_id") for n in names}

    hits = [1 if rid in relevant else 0 for rid in retrieved]
    hit_at_k = float(any(hits))
    recall = sum(hits) / len(relevant)
    precision = sum(hits) / len(retrieved)

    rr = 0.0
    for rank, hit in enumerate(hits, start=1):
        if hit:
            rr = 1.0 / rank
            break

    dcg = sum(hit / math.log2(rank + 1) for rank, hit in enumerate(hits, start=1))
    ideal_count = min(len(relevant), len(retrieved))
    idcg = sum(1 / math.log2(rank + 1) for rank in range(1, ideal_count + 1))
    ndcg = dcg / idcg if idcg else 0.0

    values = {
        "Hit@K": (hit_at_k, thresholds.hit_at_k),
        "Recall@K": (recall, thresholds.recall_at_k),
        "Precision@K": (precision, thresholds.precision_at_k),
        "MRR": (rr, thresholds.mrr),
        "NDCG@K": (ndcg, thresholds.ndcg_at_k),
    }

    return {
        name: MetricResult(
            name=name,
            status="completed",
            score=score,
            threshold=threshold,
            passed=score >= threshold,
            reason="Deterministic retrieval metric",
            details={"retrieved_chunk_ids": retrieved, "relevant_chunk_ids": sorted(relevant)}
        )
        for name, (score, threshold) in values.items()
    }

def evaluate_document_hit(case):
    name = "Document Hit@K"
    if not case.retrieval_context:
        return MetricResult(name=name, status="missing", reason="No retrieval_context")
    relevant = set(case.relevant_document_ids)
    if not relevant:
        return MetricResult(name=name, status="not_applicable", reason="No relevant_document_ids")
    retrieved = {c.document_id for c in case.retrieval_context if c.document_id}
    score = float(bool(relevant & retrieved))
    return MetricResult(
        name=name, status="completed", score=score, threshold=1.0,
        passed=score >= 1.0, reason="Expected document retrieval check"
    )
