from deepeval.models import AzureOpenAIModel

def build_judge(settings):
    return AzureOpenAIModel(
        model=settings.azure_model_name,
        deployment_name=settings.azure_openai_deployment_name,
        api_key=settings.azure_openai_api_key,
        api_version=settings.azure_openai_api_version,
        base_url=settings.azure_openai_endpoint,
        temperature=0,
    )
