from dataclasses import dataclass
from typing import Any, Callable
from deepeval.metrics import (
    AnswerRelevancyMetric,
    FaithfulnessMetric,
    ContextualPrecisionMetric,
    ContextualRecallMetric,
    ContextualRelevancyMetric,
    GEval,
    ToolCorrectnessMetric,
    ArgumentCorrectnessMetric,
)
try:
    from deepeval.metrics import BiasMetric
except ImportError:
    BiasMetric = None
try:
    from deepeval.metrics import ToxicityMetric
except ImportError:
    ToxicityMetric = None

from deepeval.test_case import LLMTestCaseParams

@dataclass(frozen=True)
class MetricSpec:
    name: str
    factory: Callable[[], Any]
    requirements: frozenset[str]
    hard_gate: bool = False

def build_metric_specs(settings, judge):
    t = settings.thresholds
    verbose = settings.eval_verbose

    specs = [
        MetricSpec(
            "Answer Relevancy",
            lambda: AnswerRelevancyMetric(threshold=t.answer_relevancy, model=judge, include_reason=True, verbose_mode=verbose),
            frozenset({"actual_output"}),
            True,
        ),
        MetricSpec(
            "Faithfulness",
            lambda: FaithfulnessMetric(threshold=t.faithfulness, model=judge, include_reason=True, verbose_mode=verbose),
            frozenset({"actual_output", "retrieval_context"}),
            True,
        ),
        MetricSpec(
            "Contextual Relevancy",
            lambda: ContextualRelevancyMetric(threshold=t.contextual_relevancy, model=judge, include_reason=True, verbose_mode=verbose),
            frozenset({"actual_output", "retrieval_context"}),
        ),
        MetricSpec(
            "Contextual Precision",
            lambda: ContextualPrecisionMetric(threshold=t.contextual_precision, model=judge, include_reason=True, verbose_mode=verbose),
            frozenset({"actual_output", "expected_output", "retrieval_context"}),
        ),
        MetricSpec(
            "Contextual Recall",
            lambda: ContextualRecallMetric(threshold=t.contextual_recall, model=judge, include_reason=True, verbose_mode=verbose),
            frozenset({"actual_output", "expected_output", "retrieval_context"}),
            True,
        ),
        MetricSpec(
            "Correctness",
            lambda: GEval(
                name="Correctness",
                criteria="Judge whether the actual output is factually correct relative to the expected output. Penalize contradictions, wrong amounts, wrong conditions, and materially incorrect claims.",
                evaluation_params=[
                    LLMTestCaseParams.INPUT,
                    LLMTestCaseParams.ACTUAL_OUTPUT,
                    LLMTestCaseParams.EXPECTED_OUTPUT,
                ],
                threshold=t.correctness,
                model=judge,
            ),
            frozenset({"actual_output", "expected_output"}),
            True,
        ),
        MetricSpec(
            "Completeness",
            lambda: GEval(
                name="Completeness",
                criteria="Judge whether the actual output covers all materially important facts, qualifications, exceptions, conditions, and sub-questions contained in the expected output.",
                evaluation_params=[
                    LLMTestCaseParams.INPUT,
                    LLMTestCaseParams.ACTUAL_OUTPUT,
                    LLMTestCaseParams.EXPECTED_OUTPUT,
                ],
                threshold=t.completeness,
                model=judge,
            ),
            frozenset({"actual_output", "expected_output"}),
        ),
        MetricSpec(
            "Domain Accuracy",
            lambda: GEval(
                name="Domain Accuracy",
                criteria="Preserve monetary amounts, percentages, deductible/copay/coinsurance distinctions, network status, coverage conditions, exclusions, limits, and temporal qualifiers. Do not infer unsupported benefits.",
                evaluation_params=[
                    LLMTestCaseParams.INPUT,
                    LLMTestCaseParams.ACTUAL_OUTPUT,
                    LLMTestCaseParams.EXPECTED_OUTPUT,
                    LLMTestCaseParams.RETRIEVAL_CONTEXT,
                ],
                threshold=t.domain_accuracy,
                model=judge,
            ),
            frozenset({"actual_output", "expected_output", "retrieval_context"}),
            True,
        ),
    ]

    if settings.enable_agent_metrics:
        specs += [
            MetricSpec(
                "Tool Correctness",
                lambda: ToolCorrectnessMetric(threshold=t.tool_correctness, model=judge, include_reason=True, verbose_mode=verbose),
                frozenset({"actual_output", "tools_called", "expected_tools"}),
            ),
            MetricSpec(
                "Argument Correctness",
                lambda: ArgumentCorrectnessMetric(threshold=t.argument_correctness, model=judge, include_reason=True, verbose_mode=verbose),
                frozenset({"actual_output", "tools_called"}),
            ),
        ]

    if settings.enable_safety:
        if BiasMetric is not None:
            specs.append(MetricSpec("Bias", lambda: BiasMetric(model=judge, include_reason=True), frozenset({"actual_output"})))
        if ToxicityMetric is not None:
            specs.append(MetricSpec("Toxicity", lambda: ToxicityMetric(model=judge, include_reason=True), frozenset({"actual_output"})))

    return specs
