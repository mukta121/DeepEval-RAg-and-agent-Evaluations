from deepeval.test_case import LLMTestCase, ToolCall
from .deterministic_metrics import evaluate_document_hit, evaluate_retrieval
from .metric_registry import build_metric_specs
from .models import MetricResult, QuestionResult

def _tool(record):
    return ToolCall(
        name=record.name,
        description=record.description,
        reasoning=record.reasoning,
        input_parameters=record.input_parameters,
        output=record.output,
    )

def _has(case, field):
    value = getattr(case, field)
    return value is not None and value != "" and value != [] and value != {}

def build_test_case(case):
    kwargs = {"input": case.query, "actual_output": case.actual_output}
    if case.expected_output:
        kwargs["expected_output"] = case.expected_output
    if case.retrieval_context:
        kwargs["retrieval_context"] = [c.content for c in case.retrieval_context]
    if case.tools_called:
        kwargs["tools_called"] = [_tool(t) for t in case.tools_called]
    if case.expected_tools:
        kwargs["expected_tools"] = [_tool(t) for t in case.expected_tools]
    return LLMTestCase(**kwargs)

def run_metric(spec, case, test_case):
    missing = [f for f in spec.requirements if not _has(case, f)]
    if missing:
        status = "not_applicable" if "expected_output" in missing else "missing"
        result = MetricResult(name=spec.name, status=status, reason=f"Requires: {', '.join(missing)}")
        return result, {"metric": spec.name, "status": status, "missing_requirements": missing}

    metric = spec.factory()
    threshold = getattr(metric, "threshold", None)

    try:
        metric.measure(test_case)
        score = getattr(metric, "score", None)
        score = float(score) if isinstance(score, (int, float)) else None

        passed = None
        is_successful = getattr(metric, "is_successful", None)
        if callable(is_successful):
            try:
                passed = bool(is_successful())
            except Exception:
                passed = None
        if passed is None and score is not None and isinstance(threshold, (int, float)):
            passed = score >= threshold

        reason = str(getattr(metric, "reason", "") or "")
        details = {
            "metric_class": type(metric).__name__,
            "evaluation_model": str(getattr(metric, "evaluation_model", "") or ""),
            "verbose_logs": getattr(metric, "verbose_logs", None),
        }
        result = MetricResult(
            name=spec.name,
            status="completed",
            score=score,
            threshold=float(threshold) if isinstance(threshold, (int, float)) else None,
            passed=passed,
            reason=reason,
            details={k: v for k, v in details.items() if v not in (None, "", [])},
        )
        return result, {"metric": spec.name, "status": "completed", "score": score, "threshold": threshold, "passed": passed, "reason": reason, **details}

    except Exception as exc:
        result = MetricResult(
            name=spec.name,
            status="error",
            threshold=float(threshold) if isinstance(threshold, (int, float)) else None,
            passed=False if spec.hard_gate else None,
            reason=f"{type(exc).__name__}: {exc}",
        )
        return result, {"metric": spec.name, "status": "error", "error_type": type(exc).__name__, "error": str(exc)}

def evaluate_case(*, case, question_number, settings, judge):
    test_case = build_test_case(case)
    specs = build_metric_specs(settings, judge)
    metrics = {}
    raw_metrics = []

    for spec in specs:
        result, raw = run_metric(spec, case, test_case)
        metrics[spec.name] = result
        raw_metrics.append(raw)

    metrics.update(evaluate_retrieval(case, settings.thresholds))
    doc_hit = evaluate_document_hit(case)
    metrics[doc_hit.name] = doc_hit

    hard_gate_metrics = {s.name for s in specs if s.hard_gate}
    if case.relevant_chunk_ids:
        hard_gate_metrics.update({"Hit@K", "Recall@K"})

    result = QuestionResult.finalize(
        case=case,
        question_number=question_number,
        metrics=metrics,
        hard_gate_metrics=hard_gate_metrics,
    )

    raw = {
        "question_number": question_number,
        "case_id": case.case_id,
        "query": case.query,
        "expected_output": case.expected_output,
        "actual_output": case.actual_output,
        "retrieval_context": [c.model_dump() for c in case.retrieval_context],
        "tools_called": [t.model_dump() for t in case.tools_called],
        "expected_tools": [t.model_dump() for t in case.expected_tools],
        "metadata": case.metadata,
        "deepeval_metrics": raw_metrics,
    }
    return result, raw
