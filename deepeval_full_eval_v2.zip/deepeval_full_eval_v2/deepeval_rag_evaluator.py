from __future__ import annotations
import argparse
import sys
from pathlib import Path

from deepeval_eval.config import Settings
from deepeval_eval.dataset import load_ground_truth, load_responses, merge_ground_truth_and_responses
from deepeval_eval.evaluator import evaluate_case
from deepeval_eval.judge import build_judge
from deepeval_eval.reporting import aggregate_results, write_excel, write_json

def parse_args():
    parser = argparse.ArgumentParser(description="DeepEval evaluator for RAG and agent responses")
    parser.add_argument("--ground-truth", required=True, type=Path)
    parser.add_argument("--responses", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--excel-output", required=True, type=Path)
    parser.add_argument("--raw-output", required=True, type=Path)
    return parser.parse_args()

def main():
    args = parse_args()
    settings = Settings()

    ground_truth = load_ground_truth(args.ground_truth)
    responses = load_responses(args.responses)
    cases = merge_ground_truth_and_responses(ground_truth, responses)
    judge = build_judge(settings)

    results = []
    raw_cases = []

    for i, case in enumerate(cases, start=1):
        print(f"[{i}/{len(cases)}] Evaluating {case.case_id}")
        result, raw = evaluate_case(case=case, question_number=i, settings=settings, judge=judge)
        results.append(result)
        raw_cases.append(raw)

    overall = aggregate_results(results)

    write_json(args.output, {
        "summary": overall,
        "results": [r.model_dump() for r in results]
    })

    write_excel(args.excel_output, results, overall)

    write_json(args.raw_output, {
        "configuration": {
            "evaluation_model": settings.azure_model_name,
            "deployment": settings.azure_openai_deployment_name,
            "verbose": settings.eval_verbose,
            "enable_safety": settings.enable_safety,
            "enable_agent_metrics": settings.enable_agent_metrics,
            "thresholds": settings.thresholds.model_dump(),
        },
        "summary": overall,
        "cases": raw_cases,
    })

    print(f"Hard-gate pass rate: {overall['hard_gate_pass_rate']:.1%}")
    return 0 if overall["hard_gate_failed"] == 0 else 2

if __name__ == "__main__":
    sys.exit(main())
