# DeepEval Full Evaluation v2

Run:

Windows CMD:
```cmd
python deepeval_rag_evaluator.py ^
  --ground-truth data\ground_truth.json ^
  --responses data\response_generator.json ^
  --output outputs\evaluation_deepeval_result.json ^
  --excel-output outputs\evaluation_deepeval_result.xlsx ^
  --raw-output outputs\deepeval_raw_output.json
```

macOS/Linux:
```bash
python deepeval_rag_evaluator.py \
  --ground-truth data/ground_truth.json \
  --responses data/response_generator.json \
  --output outputs/evaluation_deepeval_result.json \
  --excel-output outputs/evaluation_deepeval_result.xlsx \
  --raw-output outputs/deepeval_raw_output.json
```

Both JSON and JSONL inputs are accepted.

Ground truth supports:
- case_id / id / question_id
- query / question / input / prompt
- expected_output / expected_answer / ground_truth / answer
- relevant_chunk_ids
- relevant_document_ids
- expected_tools

Response file supports:
- case_id
- query / question
- actual_output / response / generated_answer / rag_answer
- retrieval_context / retrieved_chunks / contexts
- tools_called
- latency_seconds
- token_cost

Metrics:
- Answer Relevancy
- Faithfulness
- Contextual Relevancy
- Contextual Precision
- Contextual Recall
- GEval Correctness
- GEval Completeness
- GEval Domain Accuracy
- Tool Correctness
- Argument Correctness
- Hit@K
- Recall@K
- Precision@K
- MRR
- NDCG@K
- Document Hit@K
- optional Bias/Toxicity
