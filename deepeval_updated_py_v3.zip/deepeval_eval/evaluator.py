from __future__ import annotations

from typing import Any

from deepeval.test_case import (
    LLMTestCase,
    ToolCall,
)

from .deterministic_metrics import (
    evaluate_document_hit,
    evaluate_retrieval,
)

from .metric_registry import (
    build_metric_specs,
)

from .models import (
    EvalCase,
    MetricResult,
    QuestionResult,
    ToolRecord,
)


def _to_tool_call(
    record: ToolRecord,
) -> ToolCall:

    return ToolCall(
        name=record.name,
        description=record.description,
        reasoning=record.reasoning,
        input_parameters=
            record.input_parameters,
        output=record.output,
    )


def _has(
    case: EvalCase,
    field: str,
) -> bool:

    value = getattr(
        case,
        field,
    )

    if value is None:
        return False

    if isinstance(
        value,
        (str, list, dict),
    ):
        return bool(value)

    return True


def build_test_case(
    case: EvalCase,
) -> LLMTestCase:
    """
    Build the DeepEval LLMTestCase using only fields actually available.

    This means answer-quality metrics can still run even when your
    response_generator does not expose full retrieval_context.
    """

    kwargs: dict[str, Any] = {
        "input": case.query,
        "actual_output":
            case.actual_output,
    }

    if case.expected_output:

        kwargs[
            "expected_output"
        ] = case.expected_output

    if case.retrieval_context:

        kwargs[
            "retrieval_context"
        ] = [
            chunk.content
            for chunk
            in case.retrieval_context
            if chunk.content
        ]

    if case.tools_called:

        kwargs[
            "tools_called"
        ] = [
            _to_tool_call(tool)
            for tool
            in case.tools_called
        ]

    if case.expected_tools:

        kwargs[
            "expected_tools"
        ] = [
            _to_tool_call(tool)
            for tool
            in case.expected_tools
        ]

    return LLMTestCase(
        **kwargs
    )


def _metric_threshold(
    metric: Any,
) -> float | None:

    value = getattr(
        metric,
        "threshold",
        None,
    )

    if isinstance(
        value,
        (int, float),
    ):
        return float(value)

    return None


def _metric_success(
    metric: Any,
    score: float | None,
    threshold: float | None,
) -> bool | None:

    is_successful = getattr(
        metric,
        "is_successful",
        None,
    )

    if callable(
        is_successful
    ):

        try:
            return bool(
                is_successful()
            )

        except Exception:
            pass

    success = getattr(
        metric,
        "success",
        None,
    )

    if isinstance(
        success,
        bool,
    ):
        return success

    if (
        score is not None
        and threshold is not None
    ):
        return (
            score
            >= threshold
        )

    return None


def run_metric(
    spec,
    case: EvalCase,
    test_case: LLMTestCase,
) -> tuple[
    MetricResult,
    dict[str, Any],
]:

    missing_fields = sorted(
        field
        for field
        in spec.requirements
        if not _has(
            case,
            field,
        )
    )

    if missing_fields:

        # Metrics requiring golden expected answer
        # are N/A when the golden does not have it.
        if (
            "expected_output"
            in missing_fields
        ):
            status = (
                "not_applicable"
            )

        else:
            status = "missing"

        result = MetricResult(
            name=spec.name,
            status=status,
            passed=(
                False
                if (
                    spec.hard_gate
                    and status == "missing"
                )
                else None
            ),
            reason=(
                "Requires: "
                + ", ".join(
                    missing_fields
                )
            ),
        )

        return (
            result,
            {
                "metric":
                    spec.name,

                "status":
                    status,

                "missing_requirements":
                    missing_fields,
            },
        )

    metric = spec.factory()

    threshold = _metric_threshold(
        metric
    )

    try:

        metric.measure(
            test_case
        )

        raw_score = getattr(
            metric,
            "score",
            None,
        )

        score = (
            float(raw_score)
            if isinstance(
                raw_score,
                (int, float),
            )
            else None
        )

        reason = str(
            getattr(
                metric,
                "reason",
                "",
            )
            or ""
        )

        passed = _metric_success(
            metric,
            score,
            threshold,
        )

        details = {
            "metric_class":
                type(metric).__name__,

            "evaluation_model":
                str(
                    getattr(
                        metric,
                        "evaluation_model",
                        "",
                    )
                    or ""
                ),

            "verbose_logs":
                getattr(
                    metric,
                    "verbose_logs",
                    None,
                ),
        }

        details = {
            key: value
            for key, value
            in details.items()
            if value
            not in (
                None,
                "",
                [],
            )
        }

        result = MetricResult(
            name=spec.name,
            status="completed",
            score=score,
            threshold=threshold,
            passed=passed,
            reason=reason,
            details=details,
        )

        raw = {
            "metric":
                spec.name,

            "status":
                "completed",

            "score":
                score,

            "threshold":
                threshold,

            "passed":
                passed,

            "reason":
                reason,

            **details,
        }

        return (
            result,
            raw,
        )

    except Exception as exc:

        result = MetricResult(
            name=spec.name,
            status="error",
            threshold=threshold,
            passed=(
                False
                if spec.hard_gate
                else None
            ),
            reason=(
                f"{type(exc).__name__}: "
                f"{exc}"
            ),
            details={
                "metric_class":
                    type(metric).__name__
            },
        )

        raw = {
            "metric":
                spec.name,

            "status":
                "error",

            "error_type":
                type(exc).__name__,

            "error":
                str(exc),

            "metric_class":
                type(metric).__name__,
        }

        return (
            result,
            raw,
        )


def evaluate_case(
    *,
    case: EvalCase,
    question_number: int,
    settings,
    judge,
) -> tuple[
    QuestionResult,
    dict[str, Any],
]:

    test_case = build_test_case(
        case
    )

    specs = build_metric_specs(
        settings,
        judge,
    )

    metric_results: dict[
        str,
        MetricResult,
    ] = {}

    raw_metrics: list[
        dict[str, Any]
    ] = []

    # --------------------------------------------------------
    # DeepEval metrics
    # --------------------------------------------------------

    for spec in specs:

        result, raw = run_metric(
            spec,
            case,
            test_case,
        )

        metric_results[
            spec.name
        ] = result

        raw_metrics.append(
            raw
        )

    # --------------------------------------------------------
    # Deterministic retrieval metrics
    # --------------------------------------------------------

    retrieval_results = (
        evaluate_retrieval(
            case,
            settings.thresholds,
        )
    )

    metric_results.update(
        retrieval_results
    )

    document_hit = (
        evaluate_document_hit(
            case
        )
    )

    metric_results[
        document_hit.name
    ] = document_hit

    # --------------------------------------------------------
    # Hard gates
    # --------------------------------------------------------

    hard_gate_metrics = {
        spec.name
        for spec in specs
        if spec.hard_gate
    }

    # Only add deterministic retrieval gates if
    # chunk-level ground truth exists.
    if case.relevant_chunk_ids:

        hard_gate_metrics.update(
            {
                "Hit@K",
                "Recall@K",
            }
        )

    question_result = (
        QuestionResult.finalize(
            case=case,
            question_number=
                question_number,
            metrics=
                metric_results,
            hard_gate_metrics=
                hard_gate_metrics,
        )
    )

    # --------------------------------------------------------
    # Raw output for debugging / audit
    # --------------------------------------------------------

    raw_case = {
        "question_number":
            question_number,

        "case_id":
            case.case_id,

        "query":
            case.query,

        "expected_output":
            case.expected_output,

        "actual_output":
            case.actual_output,

        "retrieval_context": [
            chunk.model_dump()
            for chunk
            in case.retrieval_context
        ],

        "citations": [
            citation.model_dump(
                exclude_none=True
            )
            for citation
            in case.citations
        ],

        "tools_called": [
            tool.model_dump()
            for tool
            in case.tools_called
        ],

        "expected_tools": [
            tool.model_dump()
            for tool
            in case.expected_tools
        ],

        "metadata":
            case.metadata,

        "deepeval_metrics":
            raw_metrics,

        "deterministic_metrics": {
            name:
                result.model_dump()
            for name, result
            in metric_results.items()
            if name in {
                "Hit@K",
                "Recall@K",
                "Precision@K",
                "MRR",
                "NDCG@K",
                "Document Hit@K",
            }
        },
    }

    return (
        question_result,
        raw_case,
    )
