from __future__ import annotations

from typing import Any, Literal
from pydantic import BaseModel, ConfigDict, Field


class ToolRecord(BaseModel):
    name: str
    description: str | None = None
    reasoning: str | None = None
    input_parameters: dict[str, Any] | None = None
    output: Any | None = None


class RetrievedChunk(BaseModel):
    """
    Canonical retrieved chunk used by DeepEval.

    Extra fields are retained because different RAG APIs may return
    search-specific metadata such as reranker_score, page_number, etc.
    """
    model_config = ConfigDict(extra="allow")

    chunk_id: str | None = None
    document_id: str | None = None
    content: str
    rank: int | None = None
    score: float | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class CitationRecord(BaseModel):
    """
    Structured citation returned by the RAG application.

    Your current response_generator file returns citation objects rather
    than strings, so citations must be modeled as objects.
    """
    model_config = ConfigDict(extra="allow")

    chunk_number: int | None = None
    chunk_id: str | None = None
    document_id: str | None = None
    title: str | None = None
    source: str | None = None
    url: str | None = None
    content: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class GroundTruthCase(BaseModel):
    model_config = ConfigDict(extra="allow")

    case_id: str
    query: str
    expected_output: str | None = None

    relevant_chunk_ids: list[str] = Field(default_factory=list)
    relevant_document_ids: list[str] = Field(default_factory=list)

    expected_tools: list[ToolRecord] = Field(default_factory=list)
    expected_citations: list[str] = Field(default_factory=list)

    category: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ResponseCase(BaseModel):
    model_config = ConfigDict(extra="allow")

    case_id: str
    query: str | None = None
    actual_output: str

    retrieval_context: list[RetrievedChunk] = Field(default_factory=list)

    tools_called: list[ToolRecord] = Field(default_factory=list)

    # IMPORTANT: structured citation objects, not list[str]
    citations: list[CitationRecord] = Field(default_factory=list)

    latency_seconds: float | None = None
    token_cost: float | None = None

    metadata: dict[str, Any] = Field(default_factory=dict)


class EvalCase(BaseModel):
    model_config = ConfigDict(extra="allow")

    case_id: str
    query: str

    expected_output: str | None = None
    actual_output: str

    relevant_chunk_ids: list[str] = Field(default_factory=list)
    relevant_document_ids: list[str] = Field(default_factory=list)

    retrieval_context: list[RetrievedChunk] = Field(default_factory=list)

    tools_called: list[ToolRecord] = Field(default_factory=list)
    expected_tools: list[ToolRecord] = Field(default_factory=list)

    citations: list[CitationRecord] = Field(default_factory=list)
    expected_citations: list[str] = Field(default_factory=list)

    category: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


MetricStatus = Literal[
    "completed",
    "missing",
    "not_applicable",
    "error",
]


class MetricResult(BaseModel):
    name: str
    status: MetricStatus
    score: float | None = None
    label: str | None = None
    passed: bool | None = None
    threshold: float | None = None
    reason: str = ""
    details: dict[str, Any] = Field(default_factory=dict)


class QuestionResult(BaseModel):
    case_id: str
    question_number: int
    query: str

    actual_output: str
    expected_output: str | None = None

    metrics: dict[str, MetricResult]

    hard_gate_passed: bool

    applicable_metrics: int
    passed_metrics: int
    failed_metrics: int
    missing_metrics: int
    error_metrics: int
    not_applicable_metrics: int

    @classmethod
    def finalize(
        cls,
        *,
        case: EvalCase,
        question_number: int,
        metrics: dict[str, MetricResult],
        hard_gate_metrics: set[str],
    ) -> "QuestionResult":
        completed = [
            metric
            for metric in metrics.values()
            if metric.status == "completed"
        ]

        passed = [
            metric
            for metric in completed
            if metric.passed is True
        ]

        failed = [
            metric
            for metric in completed
            if metric.passed is False
        ]

        missing = [
            metric
            for metric in metrics.values()
            if metric.status == "missing"
        ]

        errors = [
            metric
            for metric in metrics.values()
            if metric.status == "error"
        ]

        not_applicable = [
            metric
            for metric in metrics.values()
            if metric.status == "not_applicable"
        ]

        hard_gate_passed = all(
            (metric := metrics.get(metric_name)) is not None
            and metric.status == "completed"
            and metric.passed is True
            for metric_name in hard_gate_metrics
        )

        return cls(
            case_id=case.case_id,
            question_number=question_number,
            query=case.query,
            actual_output=case.actual_output,
            expected_output=case.expected_output,
            metrics=metrics,
            hard_gate_passed=hard_gate_passed,
            applicable_metrics=len(completed),
            passed_metrics=len(passed),
            failed_metrics=len(failed),
            missing_metrics=len(missing),
            error_metrics=len(errors),
            not_applicable_metrics=len(not_applicable),
        )
