from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from .models import (
    CitationRecord,
    EvalCase,
    GroundTruthCase,
    ResponseCase,
)


# ============================================================
# FIELD ALIASES
# ============================================================

ALIASES = {
    "case_id": (
        "case_id",
        "id",
        "question_id",
        "test_case_id",
    ),

    "query": (
        "query",
        "question",
        "input",
        "prompt",
    ),

    # Matches your actual ground_truth file.
    "expected_output": (
        "expected_output",
        "expected_answer",
        "ground_truth",
        "ground_truth_answer",
        "answer",
        "reference_answer",
    ),

    # Matches your actual response_generator file.
    "actual_output": (
        "actual_output",
        "response",
        "generated_answer",
        "model_answer",
        "rag_answer",
        "output",
    ),

    "retrieval_context": (
        "retrieval_context",
        "retrieved_chunks",
        "retrieved_context",
        "contexts",
        "context",
        "search_results",
    ),

    "relevant_chunk_ids": (
        "relevant_chunk_ids",
        "expected_chunk_ids",
        "gold_chunk_ids",
    ),

    "relevant_document_ids": (
        "relevant_document_ids",
        "expected_document_ids",
        "gold_document_ids",
    ),
}


# ============================================================
# HELPERS
# ============================================================

def _normalize_query(query: str | None) -> str:
    return " ".join(
        (query or "").casefold().split()
    )


def _stable_case_id(query: str, index: int) -> str:
    """
    Stable query-based ID.

    This is safer than Q00001/Q00002 because ground truth and response files
    do not need to remain in exactly the same physical order.
    """
    normalized = _normalize_query(query)

    if not normalized:
        return f"Q{index:05d}"

    digest = hashlib.sha256(
        normalized.encode("utf-8")
    ).hexdigest()[:12]

    return f"Q_{digest}"


def _first(
    record: dict[str, Any],
    names: tuple[str, ...],
) -> Any:
    for name in names:
        if (
            name in record
            and record[name] is not None
        ):
            return record[name]

    return None


# ============================================================
# JSON / JSONL AUTO DETECTION
# ============================================================

def _read_json_or_jsonl(
    path: Path,
) -> list[dict[str, Any]]:
    """
    Supports:

    - Standard JSON array
    - Standard JSON object
    - JSON wrapper containing data/cases/results/etc.
    - JSONL / NDJSON
    - JSONL content even when the file extension is .json

    This specifically fixes:
        JSONDecodeError: Extra data: line 2 column 1
    """

    if not path.exists():
        raise FileNotFoundError(
            f"Input file not found: {path}"
        )

    if not path.is_file():
        raise ValueError(
            f"Input path is not a file: {path}"
        )

    text = path.read_text(
        encoding="utf-8"
    ).strip()

    if not text:
        raise ValueError(
            f"Input file is empty: {path}"
        )

    # --------------------------------------------------------
    # First attempt: normal JSON
    # --------------------------------------------------------

    try:
        payload = json.loads(text)

    except json.JSONDecodeError as standard_json_error:

        # ----------------------------------------------------
        # Second attempt: JSONL / NDJSON
        # ----------------------------------------------------

        records: list[dict[str, Any]] = []

        for line_number, line in enumerate(
            text.splitlines(),
            start=1,
        ):
            line = line.strip()

            if not line:
                continue

            try:
                record = json.loads(line)

            except json.JSONDecodeError as jsonl_error:
                raise ValueError(
                    f"\nUnable to parse file: {path}\n\n"
                    f"Standard JSON error:\n"
                    f"  {standard_json_error}\n\n"
                    f"JSONL error at line {line_number}:\n"
                    f"  {jsonl_error}\n\n"
                    "The file is neither valid JSON nor valid JSONL."
                ) from jsonl_error

            if not isinstance(record, dict):
                raise ValueError(
                    f"{path}: JSONL line "
                    f"{line_number} must contain "
                    "one JSON object."
                )

            records.append(record)

        if not records:
            raise ValueError(
                f"No JSON records found in {path}."
            )

        print(
            f"Detected JSONL/NDJSON content in "
            f"{path.name}: {len(records)} records."
        )

        return records

    # --------------------------------------------------------
    # Standard JSON parsed successfully.
    # --------------------------------------------------------

    if isinstance(payload, list):
        records = payload

    elif isinstance(payload, dict):

        records = None

        for key in (
            "data",
            "cases",
            "golden_data",
            "goldens",
            "test_cases",
            "evaluation_cases",
            "responses",
            "results",
        ):
            value = payload.get(key)

            if isinstance(value, list):
                records = value
                break

        if records is None:
            records = [payload]

    else:
        raise ValueError(
            f"{path}: JSON root must be "
            "an array or object."
        )

    for index, record in enumerate(
        records,
        start=1,
    ):
        if not isinstance(record, dict):
            raise ValueError(
                f"{path}: record #{index} "
                "is not a JSON object."
            )

    return records


# ============================================================
# CHUNK NORMALIZATION
# ============================================================

def _normalize_chunk(
    item: Any,
    index: int,
) -> dict[str, Any]:

    if isinstance(item, str):
        return {
            "content": item,
            "rank": index,
        }

    if not isinstance(item, dict):
        return {
            "content": str(item),
            "rank": index,
        }

    output = dict(item)

    if "content" not in output:
        for key in (
            "text",
            "chunk_text",
            "page_content",
            "document",
            "passage",
        ):
            if key in output:
                output["content"] = output[key]
                break

    output.setdefault(
        "content",
        "",
    )

    output.setdefault(
        "rank",
        index,
    )

    if "chunk_id" not in output:
        for key in (
            "id",
            "chunkId",
            "chunk_key",
        ):
            if key in output:
                output["chunk_id"] = output[key]
                break

    if "document_id" not in output:
        for key in (
            "documentId",
            "doc_id",
            "source_document_id",
        ):
            if key in output:
                output["document_id"] = output[key]
                break

    return output


# ============================================================
# CITATION NORMALIZATION
# ============================================================

def _normalize_citations(
    citations: Any,
) -> list[dict[str, Any]]:
    """
    Accepts both:

        "citations": ["source1", "source2"]

    and your actual format:

        "citations": [
            {
                "chunk_number": 1,
                ...
            }
        ]
    """

    if citations is None:
        return []

    if not isinstance(
        citations,
        list,
    ):
        citations = [citations]

    normalized: list[dict[str, Any]] = []

    for citation in citations:

        if isinstance(
            citation,
            dict,
        ):
            normalized.append(
                dict(citation)
            )

        elif isinstance(
            citation,
            str,
        ):
            normalized.append(
                {
                    "source": citation
                }
            )

        else:
            normalized.append(
                {
                    "source": str(citation)
                }
            )

    return normalized


# ============================================================
# RECORD NORMALIZATION
# ============================================================

def _normalize_record(
    record: dict[str, Any],
    *,
    kind: str,
    index: int,
) -> dict[str, Any]:

    output = dict(record)

    # --------------------------------------------------------
    # Field aliases
    # --------------------------------------------------------

    for canonical, aliases in ALIASES.items():

        if canonical not in output:

            value = _first(
                record,
                aliases,
            )

            if value is not None:
                output[canonical] = value

    # --------------------------------------------------------
    # Required fields
    # --------------------------------------------------------

    query = output.get(
        "query"
    )

    if (
        kind == "ground_truth"
        and not query
    ):
        raise ValueError(
            f"Ground truth record #{index} "
            "has no query/question."
        )

    if (
        kind == "response"
        and not output.get("actual_output")
    ):
        raise ValueError(
            f"Response record #{index} "
            "has no generated_answer/"
            "actual_output/response."
        )

    # --------------------------------------------------------
    # Stable case ID
    # --------------------------------------------------------

    if not output.get(
        "case_id"
    ):
        output["case_id"] = _stable_case_id(
            query=query or "",
            index=index,
        )

    # --------------------------------------------------------
    # Retrieval context
    # --------------------------------------------------------

    retrieval_context = output.get(
        "retrieval_context"
    )

    if retrieval_context is not None:

        if isinstance(
            retrieval_context,
            str,
        ):
            retrieval_context = [
                retrieval_context
            ]

        elif not isinstance(
            retrieval_context,
            list,
        ):
            retrieval_context = [
                retrieval_context
            ]

        output["retrieval_context"] = [
            _normalize_chunk(
                item,
                chunk_index,
            )
            for chunk_index, item
            in enumerate(
                retrieval_context,
                start=1,
            )
        ]

    # --------------------------------------------------------
    # Structured citations
    # --------------------------------------------------------

    if kind == "response":

        output["citations"] = _normalize_citations(
            output.get("citations")
        )

    return output


# ============================================================
# LOADERS
# ============================================================

def load_ground_truth(
    path: Path | str,
) -> list[GroundTruthCase]:

    path = Path(path)

    records = _read_json_or_jsonl(
        path
    )

    cases: list[GroundTruthCase] = []

    for index, record in enumerate(
        records,
        start=1,
    ):

        normalized = _normalize_record(
            record,
            kind="ground_truth",
            index=index,
        )

        try:
            cases.append(
                GroundTruthCase.model_validate(
                    normalized
                )
            )

        except Exception as exc:
            raise ValueError(
                f"{path}: invalid ground-truth "
                f"record #{index}: {exc}"
            ) from exc

    return cases


def load_responses(
    path: Path | str,
) -> list[ResponseCase]:

    path = Path(path)

    records = _read_json_or_jsonl(
        path
    )

    cases: list[ResponseCase] = []

    for index, record in enumerate(
        records,
        start=1,
    ):

        normalized = _normalize_record(
            record,
            kind="response",
            index=index,
        )

        try:
            cases.append(
                ResponseCase.model_validate(
                    normalized
                )
            )

        except Exception as exc:
            raise ValueError(
                f"{path}: invalid response "
                f"record #{index}: {exc}"
            ) from exc

    return cases


# ============================================================
# MERGING
# ============================================================

def merge_ground_truth_and_responses(
    ground_truth: list[GroundTruthCase],
    responses: list[ResponseCase],
) -> list[EvalCase]:
    """
    Preferred matching order:

    1. Exact normalized query
    2. case_id

    Query matching is preferred because your current input files do not
    provide a native case_id.
    """

    # --------------------------------------------------------
    # Validate query uniqueness
    # --------------------------------------------------------

    gt_query_map: dict[str, GroundTruthCase] = {}

    for item in ground_truth:

        normalized_query = _normalize_query(
            item.query
        )

        if normalized_query in gt_query_map:
            raise ValueError(
                "Duplicate query found in "
                "ground truth:\n"
                f"{item.query}"
            )

        gt_query_map[
            normalized_query
        ] = item

    response_query_map: dict[
        str,
        ResponseCase,
    ] = {}

    for item in responses:

        normalized_query = _normalize_query(
            item.query
        )

        if not normalized_query:
            continue

        if normalized_query in response_query_map:
            raise ValueError(
                "Duplicate query found in "
                "response file:\n"
                f"{item.query}"
            )

        response_query_map[
            normalized_query
        ] = item

    response_id_map = {
        item.case_id: item
        for item in responses
    }

    merged: list[EvalCase] = []

    used_response_ids: set[str] = set()

    # --------------------------------------------------------
    # Match every golden record
    # --------------------------------------------------------

    for golden in ground_truth:

        normalized_query = _normalize_query(
            golden.query
        )

        response = response_query_map.get(
            normalized_query
        )

        # Fallback to case_id
        if response is None:
            response = response_id_map.get(
                golden.case_id
            )

        if response is None:
            raise ValueError(
                "\nNo response matched "
                "ground-truth question:\n"
                f"{golden.query}\n"
            )

        used_response_ids.add(
            response.case_id
        )

        metadata = dict(
            golden.metadata
        )

        metadata.update(
            {
                "response_metadata":
                    response.metadata,

                "latency_seconds":
                    response.latency_seconds,

                "token_cost":
                    response.token_cost,

                "query_match":
                    _normalize_query(
                        response.query
                    )
                    ==
                    normalized_query,
            }
        )

        merged.append(
            EvalCase(
                case_id=golden.case_id,

                query=golden.query,

                expected_output=
                    golden.expected_output,

                actual_output=
                    response.actual_output,

                relevant_chunk_ids=
                    golden.relevant_chunk_ids,

                relevant_document_ids=
                    golden.relevant_document_ids,

                retrieval_context=
                    response.retrieval_context,

                tools_called=
                    response.tools_called,

                expected_tools=
                    golden.expected_tools,

                citations=
                    response.citations,

                expected_citations=
                    golden.expected_citations,

                category=
                    golden.category,

                metadata=
                    metadata,
            )
        )

    # --------------------------------------------------------
    # Report unused responses
    # --------------------------------------------------------

    unused = [
        response
        for response in responses
        if response.case_id
        not in used_response_ids
    ]

    if unused:
        print(
            f"WARNING: {len(unused)} "
            "response record(s) were not "
            "matched to ground truth."
        )

    return merged
